---
title: About Me
permalink: /aboutme
---


## Education

### M.A. in Public History, Digital Humanities
Carleton University, 2020-2022

### B.A. Hons. in Anthropology and Arts and Business
Focus in Archaeology, Minor in Fine Arts/Art History
University of Waterloo, 2015-2020

## Professional Experience

### THEMUSEUM, 20__ - Present
