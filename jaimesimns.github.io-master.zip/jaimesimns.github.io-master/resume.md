---
title: Resume
description: Museum Semi-Professional
permalink: /resume
---

# Resume


## Education
### M.A. in Public History, Digital Humanities
Carleton University, 2020-2022

### B.A. Hons. in Anthropology and Arts and Business
Focus in Archaeology, Minor in Fine Arts/Art History
University of Waterloo, 2015-2020


## Professional Experience
### THEMUSEUM, June 2014 - Present
Waterloo, Ontario

### Earth Sciences Museum, April - October 2019
Waterloo, Ontario

### Waterloo Regional Museum/Doon Heritage Village, August 2017 - February 2019
Kitchener, Ontario

### Archaeological Services, Inc., April - August 2018
Burlington, Ontario

## Academic Experience
### Teaching Assistantship
* Historian's Craft, Fall 2020
* Aztecs, Winter 2020

### Research Assistantship
X-Lab, Dr. Shawn Graham
* NanoHistory, Fall 2020
* Bone Trade, Winter 2020

## Relevant Volunteer Experience
### History Graduate Student Association, Secretary-Treasurer
Ottawa, Ontario; September 2020 - Present

### Field/Lab Technician, Ahatsistari Field School (WLU)
Penetanguishene, Ontario; April - July 2016
Continuing lab work, September 2016 - June 2017
